//홈 시큐리티 모드인경우 실행

void security()
{  
  lcd.noBacklight();  //라이트를 off시킨다.
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(pkTitle);
  lcd.setCursor(0, 1);
  lcd.print("doing...");
  
  if (sensor_value < ss_sensor_standard) {   //홈 시큐리티 작동
    digitalWrite(led, LOW);
    digitalWrite(buzzer_pin, HIGH);  //레이저 포인트가 조도센서에 없는 경우 부저를 울린다.
  } else {
    digitalWrite(led, HIGH);
    digitalWrite(buzzer_pin, LOW);   //레이저 포인트가 조도센서에 있는 경우 부저를 멈춘다    
  }
  delay(10);   //0.01초마다 조도센서값을 체크
}
