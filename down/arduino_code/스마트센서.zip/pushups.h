//팔굽혀 펴기

int pushups_chk = 0;
int pushupsWaitTime = 3;

int pushups_Count = 0;
bool pushups_isUpStat = true;
bool pushups_isDownStat = false;
bool pushups_bell = false;
bool pushups_isStop = true;

void pushups_setup() {
  pushups_chk = 0;
  pushupsWaitTime = 3;
  pushups_Count = 0;
  pushups_isUpStat = true;
  pushups_isDownStat = false;
  pushups_bell = false;
  pushups_isStop = true;
}


void pushups()
{
  if (pushups_isStop) {

    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print(pkTitle);
    lcd.setCursor(0, 1);

    if (pushupsWaitTime <= 0) {
      lcd.print("doing...  " + String(pushups_Count));
    } else {
      lcd.print("ready...  " + String(pushupsWaitTime));
      if (pushups_chk < 1) {
        digitalWrite(buzzer_pin, HIGH);
      } else {
        digitalWrite(buzzer_pin, LOW);
      }
    }

    pushups_chk++;
    if (pushups_chk >= 4) { //0.2초마다 한번 실행되므로, 5번이 되면 1초이다.
      pushupsWaitTime--;
      pushups_chk = 0;
    }


    //윗몸일으켜기 하는 중 처리
    if (pushupsWaitTime < 0) {

      if (sensor_value < pu_sensor_standard) {    //내려왔을때..
        digitalWrite(led, LOW);

        if (pushups_bell) {
          pushups_bell = false;
          digitalWrite(buzzer_pin, HIGH);
        } else {
          digitalWrite(buzzer_pin, LOW);
        }
        if (pushups_isUpStat) {
          pushups_isDownStat = true;
          pushups_isUpStat = false;
        }
      } else {  //올라올때
        pushups_bell = true;
        digitalWrite(led, HIGH);
        digitalWrite(buzzer_pin, LOW);
        if (pushups_isDownStat) {
          pushups_isUpStat = true;
        }
      }

      if (pushups_isDownStat && pushups_isUpStat) {
        pushups_isDownStat = false;
        pushups_Count++;
      }
    }


  } else {
    lcd.setCursor(0, 1);
    lcd.print("Finish!! >> " + String(pushups_Count));
  }

  delay(200); //0.2초
}
