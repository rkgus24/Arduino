#include "validation.h"  //데이터 검증 및 오류 방어처리

sensor_value = analogRead(A0);

pkcode = Packages[1][pkcodeNm];  //현재 모드 이름
pkTitle = Packages[0][pkcodeNm];  //현재 모드 코드값

#include "serial.h"  //디버깅을 위한 serial값 찍어보기

lcd.clear();
lcd.setCursor(0, 0);
lcd.print(pkTitle);
