//기본 셋팅 정보

#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27, 16, 2);
byte button_white = 3;
byte button_red = 2;
int sensor_value = 0; //조도센서 저장값
byte buzzer_pin = 5;   //부저 핀
byte led = 6;

String Packages[2][7] = {
  {"Ready", "Push Ups", "Sit Ups", "Plank", "Count", "Security System"},
  {"rd", "pu", "su", "pk", "ct", "ss"}
};

byte pkcodeNm = 0;
String pkcode = Packages[1][pkcodeNm];
String pkTitle = Packages[0][pkcodeNm];

bool isDoingStat = false;  //false:Stop, true:Doing  >>  시작 or 멈추기

int VerifiWhite = 1;
int VerifiRed = 1;
