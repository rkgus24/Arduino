//흰색버튼 클릭 이벤트
void chkbutton_white() {
  if (VerifiWhite == 0 && !isDoingStat) {
    Serial.println("chkbutton_white");
    VerifiWhite = 1;
    pkcodeNm++;
  }
}

//빨강버튼 클릭 이벤트
void chkbutton_red() {
  if (pkcode != "rd") {   //ready 일때는 동작하지 않는다.
    if (VerifiRed == 0) {
      Serial.print("chkbutton_red  /  isDoingStat - ");
      Serial.println(isDoingStat);
      VerifiRed = 1;
      isDoingStat = !isDoingStat;   //현재의 반대값을 매칭
    }

    //빨간색 버튼으로 초기화 할경우, 각각 초기화 해줄 데이터 처리
    if (!isDoingStat) {
      digitalWrite(buzzer_pin, LOW);  //정지하면 알림은 종료처리한다.
      plank_setup();  //플랭크 데이터 초기화하기  >>  plank.h
      count_setup();  //숫자 세기 초기화 하기    >>  count.h
      situps_setup();  //윗몸일으켜기 초기화 하기  >>  situps.h
      pushups_setup();   //팔굽혀펴기 초기화 하기  >>  pushups.h
    }
  }
}
