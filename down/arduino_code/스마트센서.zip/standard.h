//조도센서 아날로그 기준 값
int sensor_standard = 300;


//숫자세기 카운트 >> 조도센서 아날로그
int ct_sensor_standard = 200;
//시큐리티 모드에서 사용 >> 조도센서 아날로그
int ss_sensor_standard = 100;
//플랭크
int pk_sensor_standard = 200;
//위몸일으켜기
int su_sensor_standard = 250;
//팔굽혀펴기
int pu_sensor_standard = 250;
