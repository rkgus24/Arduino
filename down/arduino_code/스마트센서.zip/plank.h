//플랭크 실행

int plank_chk = 0;
int plankTimeOut = 60;  //플랭크 운동시간
byte plankTimeOutWait = 3;  //준비 시간

int plankWaitTime = plankTimeOutWait;
int plankTimeOutDisplay = plankTimeOut + plankWaitTime;

void plank_setup() {
  plank_chk = 0;
  plankTimeOutWait = 3;  
  plankWaitTime = plankTimeOutWait;
  plankTimeOutDisplay = plankTimeOut + plankWaitTime;
}

void plank()
{
  int plankShow = plankTimeOutDisplay;
  if (plankTimeOutDisplay > plankTimeOut) {
    plankShow = plankTimeOut;
  }

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(pkTitle + " : " + String(plankShow));
  lcd.setCursor(0, 1);
  if (plankWaitTime <= 0) {
    lcd.print("doing...");
  } else {
    lcd.print("ready...  " + String(plankWaitTime));
    if (plank_chk < 1) {
      digitalWrite(buzzer_pin, HIGH);
    } else {
      digitalWrite(buzzer_pin, LOW);
    }
  }

  plank_chk++;
  if (plank_chk >= 4) { //0.2초마다 한번 실행되므로, 5번이 되면 1초이다.
    plankTimeOutDisplay--;
    plankWaitTime--;
    plank_chk = 0;
  }


  //플랭크 성공하면...
  if (plankTimeOutDisplay == 0) {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print(pkTitle);
    lcd.setCursor(0, 1);
    lcd.print("success !!");

    for (int i = 0; i < 5; i++) {
      digitalWrite(buzzer_pin, HIGH);
      delay(500);
      digitalWrite(buzzer_pin, LOW);
      delay(500);
    }
    isDoingStat = false;  //빨간색 버튼 눌러 멈춤 값 셋팅
    plank_setup();   //초기화    

  } else {  //플랭크 하는 중 처리
    if (plankWaitTime < 0) {
      if (sensor_value < pk_sensor_standard) {    //플랭크 버티지 못하고 내려앉으면 시간을 멈춘다....
        digitalWrite(led, LOW);
        digitalWrite(buzzer_pin, HIGH);
        plank_chk = 0;
      } else {  //아무도 없을때..
        digitalWrite(led, HIGH);
        digitalWrite(buzzer_pin, LOW);
      }
    }

  }
  delay(200);
}
