
  Serial.print("pkcodeNm - ");
  Serial.print(pkcodeNm);
  Serial.print(" ,    pkTitle - ");
  Serial.print(pkTitle);
  Serial.print(" ,    pkcodeeNm - ");
  Serial.print(pkcode);
  Serial.print(" ,    sensor_value - ");
  Serial.println(sensor_value);
  
