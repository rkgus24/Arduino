//숫자 세기 >> 몇명이나 이 문을 통과했는지 세보고 싶을때..

int count_validation = 0;
int count_real = 0;
bool isCountOk = false;

void count_setup() {
  count_real = 0;
  isCountOk = false;
}

void count()
{
  if (count_validation >= 2 && isCountOk) {
    isCountOk = false;
    count_real++;
    count_validation = 0;
  }

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(pkTitle + " : " + String(count_real));
  lcd.setCursor(0, 1);
  lcd.print("doing...");

  if (sensor_value < ct_sensor_standard) {    //사람이 지나갈때..    
    digitalWrite(led, LOW);
    count_validation++;
  } else {  //아무도 없을때..
    isCountOk = true;
    digitalWrite(led, HIGH);
    count_validation = 0;    
  }

  delay(100);
}
