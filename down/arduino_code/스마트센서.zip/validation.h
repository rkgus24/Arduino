//데이터값 검증 하는 부분...

if (VerifiWhite > 0) {
  delay(500);
  VerifiWhite = 0;
}
if (VerifiRed > 0) {
  delay(500);
  VerifiRed = 0;
}

if (pkcodeNm > 5) {
  pkcodeNm = 1;
}


