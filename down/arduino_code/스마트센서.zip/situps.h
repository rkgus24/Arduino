//윗몸일으켜기

int situps_chk = 0;
int situpsTimeOut = 60;  //제한시간
int situpsTimeOutWait = 3;  //준비시간
int situpsWaitTime = situpsTimeOutWait;
int situpsTimeOutDisplay = situpsTimeOut + situpsWaitTime;

int situps_Count = 0;
bool situps_isUpStat = true;
bool situps_isDownStat = false;
bool situps_bell = false;
bool situps_isStop = true;

void situps_setup() {
  situps_chk = 0;
  situpsTimeOutWait = 3;
  situpsWaitTime = situpsTimeOutWait;
  situpsTimeOutDisplay = situpsTimeOut + situpsTimeOutWait;
  situps_Count = 0;
  situps_isUpStat = true;
  situps_isDownStat = false;
  situps_bell = false;
  situps_isStop = true;
}


void situps()
{
  if (situps_isStop) {
    int situpsShow = situpsTimeOutDisplay;
    if (situpsTimeOutDisplay > situpsTimeOut) {
      situpsShow = situpsTimeOut;
    }

    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print(pkTitle + " : " + String(situpsShow));
    lcd.setCursor(0, 1);

    if (situpsWaitTime <= 0) {
      lcd.print("doing...  " + String(situps_Count));
    } else {
      lcd.print("ready...  " + String(situpsWaitTime));
      if (situps_chk < 1) {
        digitalWrite(buzzer_pin, HIGH);
      } else {
        digitalWrite(buzzer_pin, LOW);
      }
    }

    situps_chk++;
    if (situps_chk >= 4) { //0.2초마다 한번 실행되므로, 5번이 되면 1초이다.
      situpsTimeOutDisplay--;
      situpsWaitTime--;
      situps_chk = 0;
    }


    //윗몸 일으켜기 종료
    if (situpsTimeOutDisplay == 0) {
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print(pkTitle);
      lcd.setCursor(0, 1);
      lcd.print("Finish!! >> " + String(situps_Count));

      for (int i = 0; i < 5; i++) {
        digitalWrite(buzzer_pin, HIGH);
        delay(500);
        digitalWrite(buzzer_pin, LOW);
        delay(500);
      }
      situps_isStop = false;

      //isDoingStat = false;  //빨간색 버튼 눌러 멈춤 값 셋팅
      //situps_setup();   //초기화


    } else {  //윗몸일으켜기 하는 중 처리
      if (situpsWaitTime < 0) {

        if (sensor_value < su_sensor_standard) {    //내려왔을때..
          digitalWrite(led, LOW);

          if (situps_bell) {
            situps_bell = false;
            digitalWrite(buzzer_pin, HIGH);
          } else {
            digitalWrite(buzzer_pin, LOW);
          }
          if (situps_isUpStat) {
            situps_isDownStat = true;
            situps_isUpStat = false;
          }
        } else {  //올라올때
          situps_bell = true;
          digitalWrite(led, HIGH);
          digitalWrite(buzzer_pin, LOW);
          if (situps_isDownStat) {
            situps_isUpStat = true;
          }
        }

        if (situps_isDownStat && situps_isUpStat) {
          situps_isDownStat = false;
          situps_Count++;
        }
      }

    }
  } else {
    lcd.setCursor(0, 1);
    lcd.print("Finish!! >> " + String(situps_Count));
  }

  delay(200);  //0.2초에 한번씩 조도센서 값을 체크
}
